const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');
const chalk = require('chalk');

/**
You can run this from the folder it's in using: 

    node index.js ~/Desktop/filewatch/test 

'~/Desktop/filewatch/test' can be any path to a folder or file that needs to be watched.

To close watcher: ctrl+C on windows

 */
 
const r = txt => chalk.bgRed.white(txt);
const g = txt => chalk.green(txt);
const b = txt => chalk.blue(txt);
const y = txt => chalk.yellow(txt);

// gets the path from argument
const args = process.argv.slice(2);
const watchpath = path.resolve(args[0]);

// sets up the watcher
const watcher = chokidar.watch(watchpath, {ignored: /(^|[\/\\])\../}).on('all', (event, path) => {
  // do nothing
});

// log start message
console.log(`

Monitor now running...

`);

watcher.on('change', path => {

  fs.readFile(path, 'utf-8', (err, data) => {
    if (err) throw err;

    // gets last line and converts into json
    const lines = data.trim().split('\n');
    const match = lines.slice(-1)[0].match(new RegExp(/[^{\}]+(?=})/));

    try {
      const last = JSON.parse(`{${match}}`)

      // formats log message
      const messageArr = [
        ((last.message.includes('failed')) && r(` 😠  FAILED `) || null),
        `login from ${b(last.src_ip)} for user ${y(last.username)} with pwd ${y(last.password)} @ ${g(last.timestamp)}`,
      ];
      const msg = messageArr.filter(i => i).join(' ');

      // logs the line to console
      console.log(msg);

    } catch(e) {
      //console.log('OH NOOOOOOO 😱')
      return;
    }
    
});

})
